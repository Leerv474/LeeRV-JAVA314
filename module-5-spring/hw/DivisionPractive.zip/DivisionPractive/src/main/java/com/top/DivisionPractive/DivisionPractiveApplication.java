package com.top.DivisionPractive;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DivisionPractiveApplication {

	public static void main(String[] args) {
		SpringApplication.run(DivisionPractiveApplication.class, args);
	}

}
