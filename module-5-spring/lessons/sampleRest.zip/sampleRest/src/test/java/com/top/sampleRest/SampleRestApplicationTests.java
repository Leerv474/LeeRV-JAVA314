package com.top.sampleRest;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SampleRestApplicationTests {

	@Test
	void contextLoads() {
	}

}
